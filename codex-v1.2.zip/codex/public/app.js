(() => {
  'use strict';

  const form = document.getElementById('chat-form');
  const input = document.getElementById('user-input');
  const chatBox = document.getElementById('chat-box');
  const sendBtn = document.getElementById('send-btn');
  const codeInput = document.getElementById('access-code');

  const STORAGE_KEY = 'codex_access_code';
  const REQUEST_TIMEOUT_MS = 60000;
  const EXT_MAP = {
    luau: 'lua', lua: 'lua', minecraft: 'mcfunction', mcfunction: 'mcfunction',
    javascript: 'js', js: 'js', python: 'py', py: 'py', html: 'html', java: 'java',
  };

  // ----- Clave de acceso (localStorage, protegido con try/catch) -----
  function readCode() {
    try { return localStorage.getItem(STORAGE_KEY) || ''; } catch { return ''; }
  }
  function writeCode(value) {
    try { localStorage.setItem(STORAGE_KEY, value); } catch { /* sin almacenamiento */ }
  }
  codeInput.value = readCode();
  codeInput.addEventListener('input', () => writeCode(codeInput.value.trim()));

  // ----- Textarea -----
  input.addEventListener('input', () => {
    input.style.height = 'auto';
    input.style.height = Math.min(input.scrollHeight, 128) + 'px';
  });
  // Enter inserta salto de línea (necesario en Android). El botón "Enviar" es el método principal.
  // Atajo opcional para teclado físico/escritorio: Ctrl+Enter o Cmd+Enter.
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
      e.preventDefault();
      form.requestSubmit();
    }
  });

  // ----- Utilidades DOM (solo textContent, nunca innerHTML) -----
  function el(tag, className, text) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  }

  function downloadClientSide(content, filename) {
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function renderAiResponse(container, text) {
    const codeBlockRegex = /```([a-zA-Z0-9_#-]*)\n([\s\S]*?)```/g;
    let lastIndex = 0;
    let match;

    while ((match = codeBlockRegex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        container.appendChild(el('p', 'msg-text', text.substring(lastIndex, match.index)));
      }

      const lang = (match[1] || '').toLowerCase() || 'txt';
      const codeContent = match[2].trim();
      const ext = EXT_MAP[lang] || 'txt';

      const wrap = el('div', 'code-wrap');
      const head = el('div', 'code-head');
      head.appendChild(el('span', '', lang.toUpperCase()));

      const dl = el('button', 'btn', '💾 Descargar');
      dl.type = 'button';
      dl.addEventListener('click', () => downloadClientSide(codeContent, `script_${Date.now()}.${ext}`));
      head.appendChild(dl);

      wrap.appendChild(head);
      wrap.appendChild(el('pre', 'code-pre', codeContent));
      container.appendChild(wrap);

      lastIndex = codeBlockRegex.lastIndex;
    }

    if (lastIndex < text.length) {
      container.appendChild(el('p', 'msg-text', text.substring(lastIndex)));
    }
  }

  function appendMessage(sender, content) {
    const isUser = sender === 'Tú';
    const msg = el('div', 'msg ' + (isUser ? 'msg-user' : 'msg-ai'));
    msg.appendChild(el('div', 'msg-head', sender));
    if (isUser) {
      msg.appendChild(el('p', 'msg-text', content));
    } else {
      renderAiResponse(msg, content);
    }
    chatBox.appendChild(msg);
    chatBox.scrollTop = chatBox.scrollHeight;
  }

  // ----- Envío -----
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const prompt = input.value.trim();
    if (!prompt) return;

    appendMessage('Tú', prompt);
    input.value = '';
    input.style.height = 'auto';
    sendBtn.disabled = true;
    sendBtn.textContent = '...';

    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ prompt, accessCode: codeInput.value.trim() }),
        signal: controller.signal,
      });
      const data = await response.json();
      if (response.ok && data.response) {
        appendMessage('Codex', data.response);
      } else {
        appendMessage('Codex', `❌ Error: ${data.error || 'Ocurrió un problema.'}`);
      }
    } catch (err) {
      const msg = err && err.name === 'AbortError'
        ? '❌ La respuesta tardó demasiado. Intenta de nuevo.'
        : '❌ Error de conexión con el servidor.';
      appendMessage('Codex', msg);
    } finally {
      clearTimeout(timer);
      sendBtn.disabled = false;
      sendBtn.textContent = 'Enviar';
    }
  });
})();
