# Codex V1.3 — Seguridad reforzada

Cambios de seguridad:
- Bloqueo server-side de solicitudes obvias para extraer system prompt, `.env`, API keys, tokens, credenciales o código de acceso.
- Bloqueo server-side de solicitudes para modificar/desactivar la propia seguridad, autenticación, límites o configuración.
- Los secretos del servidor nunca se envían a Gemini.
- Codex no tiene shell, filesystem, navegador, herramientas externas ni ejecución de código.
- Rate limit general: 20 solicitudes/15 min por IP.
- Rate limit adicional de autenticación: 8 intentos fallidos/15 min por IP.
- Helmet + CSP, sin CORS, sin `innerHTML`.
- Node 20+ y `@google/genai` 2.24.0.

Los filtros de texto son una defensa adicional; la defensa principal es la arquitectura: los secretos no se entregan al modelo y Codex no tiene herramientas para ejecutar acciones.

Instalación: `npm install` → copia `.env.example` a `.env` → configura `GEMINI_API_KEY` y un `ACCESS_CODE` largo → `npm start`.
Nunca subas `.env` a GitHub.
